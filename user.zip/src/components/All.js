import React, {useState } from "react";
import axios from "axios";
import "../styles/All.css";
import { withRouter , useHistory} from "react-router-dom";

function All() {
  
    const history = useHistory();

    
    const [data , setData] = useState({
      
      task:"" ,
      description:""
    
    });
    
      function handleinputs(e){
        setData({...data , [e.target.name] : e.target.value });
      };
   
      function PostData(e){
        e.preventDefault();
        
        
       axios.post("/tasks" , data)
        .then(function(response){
    
          console.log(response);
          window.alert("done");
          history.push("/");
        
        }).catch((err)=>{
          console.log(err);
        })
      
      }
      
return(

<>

 

<div className="All">
<form method="POST"  onSubmit={(e)=>PostData(e)}>
  
  
  <div className="Head">
    <b><h3>   Add Your Task </h3></b>
  </div>

  <div className="row mb-3">
  <div className="col-sm-10">
    <b className="col-sm-2 col-form-label">Task
      <input type="text" className="form-control" required="true" name="task" id="inputEmail3" onChange={(e)=>{handleinputs(e)} }/>
    </b>
  </div>
  </div>
  
  <div className="row mb-3">
    <b className="col-sm-2 col-form-label">Description </b>
    <div className="form-floating">
      <textarea className="form-control" name="description" required="true" placeholder="Enter Some Info About TO-DO Task" onChange={(e)=>{handleinputs(e)}} id="floatingTextarea2" ></textarea>
    </div>

  </div>

  
  <button type="submit" className="btn btn-primary"> Done </button>

</form>
</div>

    

      
   
</>


);
}

export default withRouter(All);