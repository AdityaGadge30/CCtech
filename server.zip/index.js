var bodyparser = require("body-parser");
var express = require("express");
var app = express();
const dotenv = require('dotenv');
dotenv.config();

// var cors = require('cors');
// app.use(cors());



const port = process.env.PORT || 5000 ;

app.use(express.urlencoded({extended:false}));
app.use(express.json());
app.use(bodyparser.json());

require("./src/connection/conn");
var Employee = require("./src/model/model");



app.get("/tasks" , function(req,res){

    Employee.find({} , function(err , data){
        if(err){
            console.log(err);
        }else{
            res.send(data);
        }
    })
});

app.post("/tasks" , async (req,res)=>{

    const { task , description } = req.body;
    
    try{    
    const user = new Employee({ task , description });
    await user.save()
    .then((item)=>{ 
    
        console.log("done Succesfully");
        res.status(200).send(item);
    });
    } catch(err){ 
        console.log(err);
    }
});


app.delete("/tasks/:id" , (req,res)=>{

    Employee.findByIdAndRemove(req.params.id , (err,doc)=>{
        if(!err){
            console.log("deleted");
            res.status(200).send(doc);
        }
        else{
            console.log("err");
        }
    })
});


app.put("/tasks/:id" , (req,res)=>{

    const { task , description } = req.body;

    Employee.findByIdAndUpdate(req.params.id , { task , description } , { new : true} , function(err,data){
        if(!err){
            
            res.status(200).send(data);
            
    
        }else{
            console.log(err);
        }
    })
})


app.listen(port , function(req,res){
    console.log("server in running at port 5000");
});