const mongoose = require("mongoose");
var conn = require("../connection/conn");

const employeeSchema = new mongoose.Schema({
    task:{
        type:String
    },
    description:{
        type:String,
    }

});

const Employee = new mongoose.model("Employee" , employeeSchema);

module.exports = Employee;