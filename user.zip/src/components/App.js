import React from "react";
import '../styles/App.css';
import { BrowserRouter as Router } from "react-router-dom";
import { Switch , Route } from "react-router-dom";

import Edit from "./Edit";
import Slot from "../components/Slot";
import All from "../components/All";

function App() {
  return (
    <>
    <Router>
    
    <Switch>
      
      <Route path="/" exact component={Slot} />
      <Route path="/all" exact component={All} />
      <Route path="/update/:id" exact component={Edit} />


    </Switch>
    
    
    
    </Router>
    </>
    
  );
}


export default App;