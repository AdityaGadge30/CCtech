import React, {useState , useEffect } from "react";
import axios from "axios";
import "../styles/Edit.css";
import { withRouter  , useParams , useHistory} from "react-router-dom";

function Edit() {
    const history = useHistory(); 
    const { id } = useParams();
    const [info , setInfo] = useState({

        
      task:"" ,
      description:"",
    
      array: []
    });
  
    function handleinputs(e){
      setInfo({...info , [e.target.name] : e.target.value });
    };

    
    function UpdateData(e){
        e.preventDefault();
        axios.put("/tasks/" , info)
        .then(data=>{
          console.log(data)

          history.push("/");
        }).catch((err)=>{
            console.log(err);
          })
      }



    useEffect(()=>{
  
         axios.get("/tasks/"+id )
        .then((res)=> {
           console.log(res);
          setInfo(res.data)
        })
        .catch((err)=>{
            console.log(err); 
          })
    } , [] )

       

return(

<>

 

<div className="All">

<form method="PUT"  onSubmit={(e)=>UpdateData(e)}>
    
    

  
  
  <div className="Head">
    <b><h3>   Edit Your Task </h3></b>
  </div>

  <div className="row mb-3">
  <div className="col-sm-10">
    <b className="col-sm-2 col-form-label">Task
      <input type="text" className="form-control" required="true" name="task" autoComplete="false" autoFocus="true" value={info.task} id="inputEmail3" onChange={(e)=>{handleinputs(e)} }/>
    </b>
  </div>
  </div>
  
  <div className="row mb-3">
    <b className="col-sm-2 col-form-label">Description </b>
    <div className="form-floating">
      <textarea className="form-control"  name="description" required="true" autoComplete="false"  value={info.description} placeholder="Enter Some Info About TO-DO Task"  id="floatingTextarea2" onChange={(e)=>{handleinputs(e)}} />
    </div>

  </div>

  
  <button type="submit" className="btn btn-primary"> Done </button>

</form>
</div>

    

      
   
    
    
    
   
</>


);
}

export default withRouter(Edit);