import React, {useEffect , useState} from "react";
import axios from "axios";
import "../styles/Slot.css";
import "../../node_modules/bootstrap/dist/css/bootstrap.min.css";
import {  Link } from "react-router-dom";


export default function Slot() {
  
    const [ userdata , setUserdata ] =useState({
      info : []
    })
  
      
  function Loaddata(){
    axios.get("/getdata" )
    .then(response=>{
      console.log(response)
      setUserdata({
        info : response.data
      });
    }).catch((err)=>{
        console.log(err);
      })
    }
     
    
    useEffect(()=>{
     Loaddata();   
        }, [] )

     function deletefun(id){
        
        axios.delete("/delete/"+id )
        .then(function(response){
          Loaddata();
          console.log(response);
          window.alert("Are You Sure ??");
        
        }).catch((err)=>{
          console.log(err);
        })
      }
    
   
      



return(
  <>
  
  <div className="All"> 

      <div className="aaa">
        <h1><b>
          Task List
         <div className="adddd"> 
        <Link to={"/all"}>
          <button  className="btn btn-primary" ><b>Add-Task</b></button>
        </Link>
        </div>
        </b></h1>
      </div>


{ userdata.info.map((post,pos)=>{
        return( 



<div className="Container">
<div className="row row-cols-1 row-cols-md-3 g-4" >
    <div className="col" >
    <div className="card h-100" key={post._id}>
      
      <div className="header">
        <b className="text-muted">{post.task}</b>
      </div>

      
      <div className="main">
        <h5 className="card-title"> 
        <p className="card-text">{post.description}</p>
        <div className="up-del">
        <div className="update">
          <Link to={"/update/"+(post._id)}>
            <button className="but">Update</button>
          </Link>
        </div>
        <div className="delete">  
          <button className="but" onClick={()=>{deletefun(post._id)}}>Delete</button>
        </div>
        
        </div>
        </h5>
      </div>

     
    </div>
    </div>
</div>
</div>


  

        );
      })
    }
    
    </div>
    </>
    )
  
} 





