var mongoose = require("mongoose");

mongoose.connect("mongodb+srv://aditya:Aditya%403011@cluster0.ibql0.mongodb.net/cc?retryWrites=true&w=majority" , {
    useNewUrlParser:true,
    useUnifiedTopology:true,
    
}).then(function (){
    console.log("connection sucessful");
}).catch(function(err){
    console.log(err);
})
